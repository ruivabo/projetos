nome = "Ruiva"
print(f'Olá {nome}')
print('Olá'+nome+', tufdo bem?')
print(f'o tipo de variavel é'{type(nome)})
sobrenome = str('Loira')
print (f'olá {nome} {sobrenome} Tudo bem?')