valorUM = int(input("Insira um valor: "))
valorDois = int(input("Insira outro valor: "))
print(valorUM + valorDois, valorUM - valorDois, valorUM * valorDois, valorUM / valorDois)