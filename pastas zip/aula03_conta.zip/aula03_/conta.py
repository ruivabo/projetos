valorUM = int(input("Insira um valor: "))
valorDois = int(input("Insira outro valor: "))
r=pow(valorUM,2)
r1=pow(valorDois,2)
print('Soma',valorUM + valorDois,'\nSubtração',valorUM - valorDois, 
      '\nMultiplicação',valorUM * valorDois,'\nDivisão',valorUM / valorDois ,'\nPotência', r, r1,)