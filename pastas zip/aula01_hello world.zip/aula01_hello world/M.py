print("hello mundo")
print(1+1)
print(f"{1+1}+{1+1}")
